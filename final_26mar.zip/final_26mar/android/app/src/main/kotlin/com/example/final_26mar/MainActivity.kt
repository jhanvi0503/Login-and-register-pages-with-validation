package com.example.final_26mar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
